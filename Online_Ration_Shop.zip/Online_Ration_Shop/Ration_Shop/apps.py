from django.apps import AppConfig


class RationShopConfig(AppConfig):
    name = 'Ration_Shop'
